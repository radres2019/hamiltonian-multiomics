# Hamiltonian Eigendecomposition for Pan-Cancer Multiomics

Code for:

> Mayfield JD. Phase Transitions in Pan-Cancer Multiomics Covariance Landscapes
> Define a Universal Malignancy Coordinate. *Bioinformatics*, 2026.
> doi:10.1093/bioinformatics/btXXXX

---

## What this does

Most multi-omics integration methods rank shared molecular patterns by variance
explained. The most variance-rich pattern is not always the most prognostically
relevant one. This repository implements a framework that:

1. **Constructs a Hamiltonian** H = X^T X / n from the standardized multi-omic
   feature matrix, where eigenvectors are the collective modes of coordinated
   molecular variation and eigenvalues are their energetic scale.

2. **Ranks eigenmodes by survival** rather than variance, using AUC against a
   binary overall survival label.

3. **Computes spectral concentration** c = λ₁ / Σλ, which measures how much
   of the total variance is organized into a single dominant mode. High c
   reflects single-driver tumors (e.g., VHL-driven clear cell RCC); low c
   reflects distributed multi-driver architecture (e.g., GBM).

4. **Defines the universal malignancy coordinate** η = (eigenindex − median) / c,
   which places patients from different tumor types on a common survival axis.

5. **Identifies the critical temperature T*** at which the spectral energy
   landscape reorganizes most sharply — the computational analog of a phase
   transition — via the heat capacity peak of the free energy landscape
   F(T) = −T log Z(T).

---

## Repository structure

```
hamiltonian-multiomics/
├── src/
│   ├── __init__.py
│   ├── eigendecomposition.py   # Hamiltonian construction, decomposition, η
│   └── phase_transition.py     # Free energy landscape, C_v, T*
├── notebooks/
│   └── CPTAC_Spectral_clean.ipynb   # Annotated walkthrough
├── data/
│   └── README.md               # Data access instructions (no data committed)
├── requirements.txt
├── LICENSE
├── CITATION.cff
└── README.md
```

---

## Installation

```bash
git clone https://github.com/[USERNAME]/hamiltonian-multiomics.git
cd hamiltonian-multiomics
pip install -r requirements.txt
```

Python 3.12 was used for all analyses in the paper.

---

## Quick start

```python
from src.eigendecomposition import preprocess_modality, run_eigendecomposition
from src.phase_transition import run_phase_transition

# Preprocess each modality (samples × features DataFrames)
prot_clean  = preprocess_modality(prot,  modality_prefix="proteomics")
trans_clean = preprocess_modality(trans, modality_prefix="transcriptomics")
cnv_clean   = preprocess_modality(cnv,   modality_prefix="cnv")

# Run full eigendecomposition pipeline
results = run_eigendecomposition(
    modality_dict = {
        "proteomics":      prot_clean,
        "transcriptomics": trans_clean,
        "cnv":             cnv_clean,
    },
    os_time  = os_time,   # overall survival time (days)
    os_event = os_event,  # event indicator (1=event, 0=censored)
)

print(f"Spectral concentration c = {results['spectral_conc']:.4f}")
print(f"Top survival mode AUCs:    {results['top_mode_aucs']}")

# Free energy landscape and T*
pt = run_phase_transition(results["eigenvalues"])
print(f"Critical temperature T*  = {pt['T_star']:.4f}")
```

See `notebooks/CPTAC_Spectral_clean.ipynb` for a full annotated walkthrough
including visualization.

---

## Data

CPTAC proteogenomic data are available via the
[cptac Python package](https://github.com/PayneLab/cptac).
TCGA data are available via [cBioPortal](https://www.cbioportal.org).
See `data/README.md` for download instructions.

---

## Citation

If you use this code, please cite the paper above. A `CITATION.cff` file is
included for automated citation generation.

---

## License

MIT. See `LICENSE`.
